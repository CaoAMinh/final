export {default as GetLocationDetails} from './GetLocationDetails';
export {default as GetCategoryDetails} from './GetCategoryDetails';
export {default as GetSupplierDetails} from './GetSupplierDetails';
export {default as GetProductDetails} from './GetProductDetails';
export {default as GetUserLogin} from './GetUserLogin';
export {default as GetOrderDetails} from './GetOrderDetails';
export {default as GetCustomerDetails} from './GetCustomerDetails';
export {default as GetDashboardDetails} from './GetDashboardDetails';
export {default as GetPaymentDetails} from './GetPaymentDetails';









