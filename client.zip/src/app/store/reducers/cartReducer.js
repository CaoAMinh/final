import axios from "axios";
import {
  ADD_TO_CART,
  REMOVE_FROM_CART,
  INCREASE_QUANTITY,
  DECREASE_QUANTITY,
} from "../actions/types";
import { API_URL } from "../../../config1";

// Action types for fetching cart items
export const FETCH_CART_ITEMS_REQUEST = "FETCH_CART_ITEMS_REQUEST";
export const FETCH_CART_ITEMS_SUCCESS = "FETCH_CART_ITEMS_SUCCESS";
export const FETCH_CART_ITEMS_FAILURE = "FETCH_CART_ITEMS_FAILURE";

// Action creator to fetch cart items
export const fetchCartItems = () => {
  return async (dispatch) => {
    dispatch({ type: FETCH_CART_ITEMS_REQUEST });

    try {
      const res = await axios.get(API_URL + "/api/cart/id", {
        headers: {
          Authorization: "Bearer " + localStorage.getItem("_sid"),
        },
      });
      dispatch({
        type: FETCH_CART_ITEMS_SUCCESS,
        payload: res.data.msg,
      });
    } catch (error) {
      dispatch({
        type: FETCH_CART_ITEMS_FAILURE,
        payload: error.message,
      });
    }
  };
};

const initialState = {
  cartItems: [],
  loading: false,
  error: null,
};

export const cartReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_CART_ITEMS_REQUEST:
      return {
        ...state,
        loading: true,
        error: null,
      };
    case FETCH_CART_ITEMS_SUCCESS:
      return {
        ...state,
        loading: false,
        cartItems: action.payload,
      };
    case FETCH_CART_ITEMS_FAILURE:
      return {
        ...state,
        loading: false,
        error: action.payload,
      };
    case ADD_TO_CART:
    case INCREASE_QUANTITY:
    case DECREASE_QUANTITY:
    case REMOVE_FROM_CART:
      return {
        ...state,
        cartItems: action.payload.cartItems,
      };
    default:
      return state;
  }
};
