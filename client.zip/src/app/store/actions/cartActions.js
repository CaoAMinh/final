import axios from "axios";
import {
  ADD_TO_CART,
  REMOVE_FROM_CART,
  INCREASE_QUANTITY,
  DECREASE_QUANTITY,
} from "./types";
import { API_URL } from "../../../config1";
import swal from "sweetalert";

export const addToCart = (product) => async (dispatch, getState) => {
  let cartItems = getState().cart.cartItems;
  let updatedCartItems = [...cartItems];
  let alreadyExists = false;
  cartItems.forEach((x) => {
    if (x.productId === product.id && x.unitSize === product.unitSize) {
      alreadyExists = true;
      x.quantity += 1; // Tăng số lượng nếu sản phẩm đã tồn tại với cùng unitSize
    }
  });
  if (!alreadyExists) {
    const newCartItem = {
      ...product,
      quantity: 1,
      active: 0,
      id: cartItems.length > 0 ? cartItems[cartItems.length - 1].id + 1 : 1,
      productId: product.id,
      unitSize: product.unitSize,
    };
    updatedCartItems.push(newCartItem); // Thêm sản phẩm mới vào mảng sao
  } else {
    cartItems = cartItems.map((x) =>
      x.productId === product.id && x.unitSize === product.unitSize
        ? { ...x, quantity: x.quantity }
        : x
    );
  }
  dispatch({
    type: ADD_TO_CART,
    payload: { cartItems },
  });

  const cartItemIds = {
    productId: product.id,
    quantity: 1,
    unitSize: product.unitSize,
  };

  const res = await axios({
    url: API_URL + "/api/cart/create",
    method: "post",
    data: {
      ...cartItemIds,
    },
    headers: {
      Authorization: "Bearer " + localStorage.getItem("_sid"),
    },
  });
  try {
    const result = await res.data;
    swal("Notice", "Add to cart successfully", "success").then(() => {
      window.location.reload();
    });

    return result;
  } catch (error) {
    swal("Notice", "Add to cart no success", "error");
  }
};

export const removeFromCart = (product) => async (dispatch, getState) => {
  const cartItems = getState()
    .cart.cartItems.slice()
    .filter((x) => x.id !== product.id);
  dispatch({ type: REMOVE_FROM_CART, payload: { cartItems } });

  const res = await axios({
    url: API_URL + "/api/cart/delete",
    method: "delete",
    data: { product },
    headers: {
      Authorization: "Bearer " + localStorage.getItem("_sid"),
    },
  });
  try {
    const result = await res.data;
    return result;
  } catch (error) {
    console.log(error);
  }
};

export const incrementToCart = (product) => (dispatch, getState) => {
  const cartItems = getState().cart.cartItems.slice();
  const selectProduct = cartItems.find((item) => item.id === product.id);
  const index = cartItems.indexOf(selectProduct);
  const value = cartItems[index];
  value.quantity = value.quantity + 1;
  console.log(product);
  dispatch({
    type: INCREASE_QUANTITY,
    payload: { cartItems },
  });
  setTimeout(async () => {
    const res = await axios({
      url: API_URL + "/api/cart/edit",
      method: "put",
      data: { product },
      headers: {
        Authorization: "Bearer " + localStorage.getItem("_sid"),
      },
    });
    try {
      const result = await res.data;
      return result;
    } catch (error) {
      console.log(error);
    }
  }, 1500);
};

export const decreaseToCart = (product) => (dispatch, getState) => {
  const cartItems = getState().cart.cartItems.slice();
  const selectProduct = cartItems.find((item) => item.id === product.id);
  const index = cartItems.indexOf(selectProduct);
  const value = cartItems[index];
  if (value.qty > 1) {
    value.qty = value.qty - 1;
    value.total = value.qty * value.netPrice;
  }
  dispatch({ type: DECREASE_QUANTITY, payload: { cartItems } });
  const cartItemIds = cartItems.map((item) => ({
    productId: item.id,
    quantity: item.qty,
    unitSize: item.unitSize,
  }));

  localStorage.setItem("cartItems", JSON.stringify(cartItemIds));
};
