import React, { useContext, useEffect } from "react";
import rootRoutes from "./components/web/rootRoutes";
import NotFound from "./NotFound";
import { Route, Switch } from "react-router-dom";
import { NotificationContainer } from "react-notifications";
import "react-notifications/lib/notifications.css";
import { Provider, useDispatch, useSelector } from "react-redux";
import store from "./store";
import ProviderAuth from "../utils/Authcontext";
import { fetchCartItems } from "./store/reducers/cartReducer";

export default function App() {
  const dispatch = useDispatch();
  // const { cartItems, loading, error } = useSelector((state) => state.cart);

  useEffect(() => {
    dispatch(fetchCartItems()); // Dispatch fetchCartItems action when the component mounts
  }, [dispatch]);

  return (
    <div className="App">
      <NotificationContainer />
      <Switch>
        <Route path="/" component={rootRoutes} />
        <Route component={NotFound} />
      </Switch>{" "}
    </div>
  );
}
