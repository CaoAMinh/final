import axios from "axios";
import React, { useState } from "react";
import swal from "sweetalert";

export default function Updatepassword() {
  const [password, setPassword] = useState();

  const handleSubmitChangePassword = async () => {
    let data = { password: password };
    try {
      await axios.put("http://localhost:4000/api/customer/editUser", data, {
        headers: {
          Authorization: "Bearer " + localStorage.getItem("_sid"),
        },
      });

      swal("Notice", "Update password successfully!", "success");
    } catch (error) {
      swal("Error", "Password data invalid!", "Input Error");
    }
  };
  return (
    <>
      <div>
        <div className="form-group">
          <label className="control-label">
            Password
            <span className="required">*</span>
          </label>
          <input
            className="form-control border-form-control "
            type="password"
            name="password"
            onChange={(e) => {
              setPassword(e.target.value);
            }}
            value={password}
          />
        </div>
        <button
          type="button"
          className="btn btn-success btn-lg"
          onClick={handleSubmitChangePassword}
        >
          Update Password
        </button>
      </div>
    </>
  );
}
