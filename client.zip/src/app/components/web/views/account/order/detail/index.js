import React, { useEffect, useState } from "react";
import { GetUserLogin } from "../../../../../services";
import Moment from "react-moment";
import "../../css/index.css";
import { Link } from "react-router-dom";
import get_detail_voucher from "../../../../../../../api/get_detail_voucher";
import numberWithCommas from "../../../../../../../utils/number_thousand_separator";

const Details = (props) => {
  const [user, setUser] = useState("");
  const [list, setList] = useState(null);
  const [dataVoucher, setDataVoucher] = useState({
    data: { discount: 0 },
    ok: false,
  });
  useEffect(() => {
    const fetchData = async () => {
      let email = localStorage.getItem("email");
      if (email) {
        try {
          let value = await GetUserLogin.getCustomerDetail(email);
          if (value) {
            setUser(value.data);
          }
        } catch (error) {
          console.error("Error fetching user details:", error);
        }
      }
    };

    fetchData();
    setList(props.location?.query || null);
  }, [props.location?.query]);

  useEffect(() => {
    const fetchVoucher = async () => {
      const voucherId = list?.voucherId || 0;
      if (voucherId !== 0) {
        try {
          const result = await get_detail_voucher(voucherId);
          setDataVoucher(result);
        } catch (error) {
          console.error("Error fetching voucher details:", error);
        }
      }
    };

    if (list) {
      fetchVoucher();
    }
  }, [list]);

  const handleLogout = async (event) => {
    event.preventDefault();
    try {
      await GetUserLogin.logout();
    } catch (error) {
      console.error("Error during logout:", error);
    }
  };

  return (
    <div className="wrapper">
      <div className="gambo-Breadcrumb">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <li className="breadcrumb-item">Home</li>
                  <li className="breadcrumb-item active" aria-current="page">
                    My Orders
                  </li>
                </ol>
              </nav>
            </div>
          </div>
        </div>
      </div>
      <div className="dashboard-group">
        <div className="container">
          <div className="row">
            <div className="col-lg-12">
              <div className="user-dt">
                <div className="user-img">
                  <img src="/img/avatar/img-5.jpg" alt="" />
                  <div className="img-add">
                    <input type="file" id="file" />
                  </div>
                </div>
                <h4>{user.firstName}</h4>
                <p>+84 {user.phone}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className>
        <div className="container">
          <div className="row">
            <div className="col-lg-3 col-md-4">
              <div className="left-side-tabs">
                <div className="dashboard-left-links">
                  <Link to="/account/profile" className="user-item">
                    <i className="mdi mdi-account-outline" />
                    My profile
                  </Link>
                  <Link to="/account/order" className="user-item active">
                    <i className="uil uil-box" />
                    My Orders
                  </Link>
                  <Link to="/account/rewards" className="user-item">
                    <i className="uil uil-gift" />
                    My Voucher
                  </Link>

                  <p className="user-item" onClick={handleLogout}>
                    <i className="uil uil-exit" />
                    Logout
                  </p>
                </div>
              </div>
            </div>
            <div className="col-lg-9 col-md-8">
              <div className="dashboard-right">
                <div className="row">
                  <div className="col-md-12">
                    <div className="main-title-tab">
                      <h4>
                        <i className="uil uil-box" />
                        My Orders
                      </h4>
                    </div>
                  </div>
                  <div className="col-lg-12 col-md-12">
                    {list ? (
                      <div className="pdpt-bg">
                        <div className="pdpt-title">
                          <h6>
                            Delivery Timing :{" "}
                            {list.row.deliverydate ? (
                              <Moment format="MMMM Do YYYY">
                                {list.row.deliverydate}
                              </Moment>
                            ) : (
                              ""
                            )}
                          </h6>
                        </div>

                        <div style={{ fontSize: 16 }}>Detail order: </div>
                        <div style={{ fontSize: 16 }}>
                          Phone number: {list.row.Addresses[0].phone}
                        </div>
                        <div style={{ fontSize: 16 }}>
                          Address: {list.row.Addresses[0].shipping}
                        </div>
                        <div className="order-body10">
                          <div className="table-responsive">
                            <table className="table ucp-table table-hover">
                              <thead>
                                <tr>
                                  <th style={{ width: 130 }}>#</th>
                                  <th>Image</th>
                                  <th>Item</th>
                                  <th
                                    style={{ width: 150 }}
                                    className="text-center"
                                  >
                                    Price
                                  </th>
                                  <th
                                    style={{ width: 150 }}
                                    className="text-center"
                                  >
                                    Amount
                                  </th>
                                  <th
                                    style={{ width: 150 }}
                                    className="text-center"
                                  >
                                    Discount(%)
                                  </th>
                                  <th
                                    style={{ width: 100 }}
                                    className="text-center"
                                  >
                                    Total
                                  </th>
                                </tr>
                              </thead>
                              <tbody>
                                {list.row.Carts.map((p, index) => (
                                  <tr key={index}>
                                    <td>{p.id}</td>
                                    <td>
                                      <img
                                        src={p.photo}
                                        alt="cartimage"
                                        style={{ height: "50px" }}
                                      />
                                    </td>
                                    <td>{p.name}</td>
                                    <td className="text-center">
                                      VND <span> </span>{" "}
                                      {numberWithCommas(p.price)}
                                    </td>
                                    <td className="text-center">{p.qty}</td>
                                    <td className="text-center">
                                      {p.discount}%
                                    </td>
                                    <td className="text-center">
                                      VND <span> </span>
                                      {numberWithCommas(
                                        Math.floor(
                                          p.price * (1 - p.discount / 100)
                                        )
                                      )}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>

                          <div className="total-dt">
                            <div className="total-checkout-group">
                              <div className="cart-total-dil pt-3">
                                <h4>Delivery Charges</h4>
                                <span>
                                  VND <span> </span>{" "}
                                  {numberWithCommas(list.row.deliveryFee)}
                                </span>
                              </div>
                              {list.row.voucherId !== 0 && (
                                <div className="cart-total-dil pt-3">
                                  <h4>Voucher</h4>
                                  <span>
                                    VND <span> </span>
                                    {numberWithCommas(
                                      dataVoucher.data.discount
                                    )}
                                  </span>
                                </div>
                              )}
                            </div>
                            <div className="main-total-cart">
                              <h2>Total</h2>
                              <span>
                                VND <span> </span>{" "}
                                {numberWithCommas(list.row.grandtotal)}
                              </span>
                            </div>
                          </div>
                          <div className="track-order">
                            <h4>Track Order</h4>
                            <div
                              className="bs-wizard"
                              style={{ borderBottom: 0 }}
                            >
                              <div
                                className={
                                  list.row.status === "processing"
                                    ? "bs-wizard-step complete"
                                    : list.row.status === "shipping"
                                    ? "bs-wizard-step complete"
                                    : list.row.status === "delieverd"
                                    ? "bs-wizard-step complete"
                                    : "bs-wizard-step"
                                }
                              >
                                <div className="text-center bs-wizard-stepnum">
                                  Packed
                                </div>
                                <div className="progress">
                                  <div className="progress-bar" />
                                </div>
                                <Link href="#" className="bs-wizard-dot" />
                              </div>
                              <div
                                className={
                                  list.row.status === "shipping"
                                    ? "bs-wizard-step complete"
                                    : list.row.status === "delieverd"
                                    ? "bs-wizard-step complete"
                                    : "bs-wizard-step"
                                }
                              >
                                <div className="text-center bs-wizard-stepnum">
                                  On the way
                                </div>
                                <div className="progress">
                                  <div className="progress-bar" />
                                </div>
                                <Link href="#" className="bs-wizard-dot" />
                              </div>
                              <div
                                className={
                                  list.row.status === "delieverd"
                                    ? "bs-wizard-step complete"
                                    : "bs-wizard-step"
                                }
                              >
                                <div className="text-center bs-wizard-stepnum">
                                  Delivered
                                </div>
                                <div className="progress">
                                  <div className="progress-bar" />
                                </div>
                                <Link href="#" className="bs-wizard-dot" />
                              </div>
                            </div>
                          </div>
                          <div className="alert-offer">
                            Cashback of will be credit to Gambo Super Market
                            wallet 6-12 hours of delivery.
                          </div>
                          <div className="call-bill"></div>
                        </div>
                      </div>
                    ) : (
                      <p>Loading...</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Details;
