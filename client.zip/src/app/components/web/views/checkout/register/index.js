import React, { useState } from "react";
import { NotificationManager } from "react-notifications";
import { GetUserLogin } from "../../../../services";
import { Button } from "@mui/material";
import { useHistory } from "react-router-dom";
import "./Register.css";
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  TextField,
} from "@mui/material";

const emailRegex = RegExp(
  /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
);

const Register = () => {
  const history = useHistory();
  const [formData, setFormData] = useState({
    id: "",
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    phone: "",
    gender: "",
    formErrors: {
      firstName: "",
      email: "",
      password: "",
    },
  });
  const [disable, setDisable] = useState(true);
  const [open, setOpen] = useState(false);

  const { firstName, email, password, formErrors, lastName, phone, gender } =
    formData;
  const handleChange = (e) => {
    e.preventDefault();
    const { name, value } = e.target;
    let updatedFormErrors = { ...formData.formErrors };
    switch (name) {
      case "firstName":
        updatedFormErrors.firstName =
          value.length < 3 ? "minimum 3 characters required" : "";
        break;
      case "lastName":
        updatedFormErrors.lastName =
          value.length < 3 ? "minimum 3 characters required" : "";
        break;
      case "email":
        updatedFormErrors.email = emailRegex.test(value)
          ? ""
          : "invalid email address";
        break;

      case "password":
        updatedFormErrors.password =
          value.length < 6 ? "minimum 6 characters required" : "";
        break;
      default:
        break;
    }
    const isDisabled = email === "" || firstName === "" || password === "";
    setDisable(isDisabled);
    setFormData({ ...formData, formErrors: updatedFormErrors, [name]: value });
  };

  const handleSubmit = async () => {
    let { firstName, email, password } = formData;
    let data = { firstName: firstName, email: email, password: password };
    try {
      const result = await GetUserLogin.getUserRegister(data);

      if (!result.data.success) {
        NotificationManager.error(result.data.id);
      } else {
        NotificationManager.success("Success", "Register sucessfully!");
        setFormData({ ...formData, id: result.data.id });
        setOpen(true);
      }
    } catch (error) {
      NotificationManager.error("Form data invalid!", "Input Error");
    }
  };

  const handleUpdateInfor = async (event) => {
    event.preventDefault();
    const { id, firstName, lastName, phone, email, gender } = formData;
    const data = {
      id: id,
      firstName: firstName,
      lastName: lastName,
      phone: phone,
      email: email,
      gender: gender,
    };
    let user = await GetUserLogin.getCustomerUpdate(data);
    if (user) {
      NotificationManager.success("Successfully Update", "Profile");
    } else {
      NotificationManager.error("Please check your Field", "Input Error");
    }
    setOpen(false);
    history.push("/");
  };

  return (
    <div className="card checkout-step-one">
      <div className="card-header" id="headingOne">
        <h5 className="mb-0">
          <button
            className="btn btn-link"
            type="button"
            data-toggle="collapse"
            data-target="#collapseOne"
            aria-expanded="true"
            aria-controls="collapseOne"
          >
            <span className="number">1</span> Login or SignUp
          </button>
        </h5>
      </div>
      <div
        id="collapseOne"
        className="collapse show"
        aria-labelledby="headingOne"
        data-parent="#accordionExample"
      >
        <div
          className="modal-dialog modal-lg modal-dialog-centered"
          role="document"
        >
          <div className="modal-content">
            <div className="modal-body">
              <div className="login-modal login-page-bk">
                <div className="row">
                  <div className="col-lg-6 pad-right-0">
                    <div className="login-modal-left"></div>
                  </div>
                  <div className="col-lg-6 pad-left-0">
                    <div noValidate>
                      <h5 className="heading-design-h5">Register Now!</h5>
                      <fieldset className="form-group">
                        <label>First Name</label>
                        <input
                          type="text"
                          className="form-control"
                          name="firstName"
                          value={firstName || ""}
                          onChange={handleChange}
                        />
                        {formErrors.firstName.length > 0 && (
                          <span className="errorMessage">
                            {formErrors.firstName}
                          </span>
                        )}
                      </fieldset>
                      <fieldset className="form-group">
                        <label>Enter Email/Mobile number</label>
                        <input
                          type="text"
                          className="form-control"
                          name="email"
                          value={email || ""}
                          onChange={handleChange}
                        />
                        {formErrors.email.length > 0 && (
                          <span className="errorMessage">
                            {formErrors.email}
                          </span>
                        )}
                      </fieldset>
                      <fieldset className="form-group">
                        <label>Enter Password</label>
                        <input
                          type="password"
                          className="form-control"
                          name="password"
                          value={password || ""}
                          onChange={handleChange}
                        />
                        {formErrors.password.length > 0 && (
                          <span className="errorMessage">
                            {formErrors.password}
                          </span>
                        )}
                      </fieldset>
                      <fieldset className="form-group">
                        <button
                          type="submit"
                          className="btn btn-lg btn-secondary btn-block"
                          onClick={handleSubmit}
                          disabled={disable}
                        >
                          Create Your Account
                        </button>
                      </fieldset>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Dialog open={open}>
        <DialogTitle sx={{ color: "green" }}>
          Create account sucesssfully!
        </DialogTitle>
        <DialogTitle sx={{ color: "blue", fontSize: 20, paddingTop: "0px" }}>
          Update information
        </DialogTitle>{" "}
        <DialogContent>
          {" "}
          <TextField
            fullWidth
            id="outlined-basic"
            label="Last name"
            variant="outlined"
            name="lastName"
            value={lastName || ""}
            onChange={handleChange}
            sx={{ marginTop: 2 }}
          />
        </DialogContent>
        <DialogContent sx={{ display: "flex", gap: 4 }}>
          <FormControl sx={{ marginTop: 2 }} fullWidth>
            <InputLabel id="demo-simple-select-label">Gender</InputLabel>
            <Select
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              name="gender"
              value={gender}
              label="Gender"
              onChange={handleChange}
            >
              <MenuItem value="Nam">Nam</MenuItem>
              <MenuItem value="Nu">Nu</MenuItem>
            </Select>
          </FormControl>
          <TextField
            fullWidth
            id="outlined-basic"
            label="Phone"
            variant="outlined"
            name="phone"
            value={phone || ""}
            onChange={handleChange}
            sx={{ marginTop: 2 }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleUpdateInfor} color="primary">
            Update
          </Button>{" "}
        </DialogActions>
        <DialogActions>
          <Button
            onClick={() => {
              setOpen(false);
              history.push("/");
            }}
            color="primary"
          >
            Update later
          </Button>
        </DialogActions>{" "}
      </Dialog>
    </div>
  );
};

export default Register;
