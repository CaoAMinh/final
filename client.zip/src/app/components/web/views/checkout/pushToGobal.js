// ExternalRedirect.js
import { useEffect } from "react";
import { useHistory } from "react-router-dom";

export default function ExternalRedirect(url) {
  const history = useHistory();

  useEffect(() => {
    // URL bạn muốn chuyển hướng đến
    const externalUrl = url;

    // Chuyển hướng đến URL bên ngoài
  }, [history]);

  return null; // Không render gì cả
}
