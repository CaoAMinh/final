import { NotificationManager } from "react-notifications";
import PropTypes from "prop-types";
import { Input as BaseInput } from "@mui/base/Input";
import { Box, styled } from "@mui/system";
import "./Register.css";
import * as React from "react";
import axios from "axios";
import swal from "sweetalert";
import { useHistory } from "react-router-dom";
const emailRegex = RegExp(
  /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/
);

const ForgetPassword = () => {
  const history = useHistory();
  const [formData, setFormData] = React.useState({
    id: "",
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    phone: "",
    gender: "",
    formErrors: {
      firstName: "",
      email: "",
      password: "",
    },
  });
  const [disable, setDisable] = React.useState(true);
  const [active, setActive] = React.useState(false);
  const [otp, setOtp] = React.useState("");
  const [setChangePass, setsetChangePass] = React.useState(false);
  const { email, formErrors, password } = formData;

  const handleChange = (e) => {
    e.preventDefault();
    const { name, value } = e.target;
    let updatedFormErrors = { ...formData.formErrors };
    switch (name) {
      case "firstName":
        updatedFormErrors.firstName =
          value.length < 3 ? "minimum 3 characters required" : "";
        break;
      case "lastName":
        updatedFormErrors.lastName =
          value.length < 3 ? "minimum 3 characters required" : "";
        break;
      case "email":
        updatedFormErrors.email = emailRegex.test(value)
          ? ""
          : "invalid email address";
        break;

      case "password":
        updatedFormErrors.password =
          value.length < 6 ? "minimum 6 characters required" : "";
        break;
      default:
        break;
    }
    const isDisabled = email === "";
    setDisable(isDisabled);
    setFormData({ ...formData, formErrors: updatedFormErrors, [name]: value });
  };

  const handleSubmit = async () => {
    let { email } = formData;
    let data = { email: email };
    try {
      await axios.post("http://localhost:4000/api/customer/forget", data);
      setActive(true);
    } catch (error) {
      NotificationManager.error("Form data invalid!", "Input Error");
    }
  };
  const handleSubmitOtp = async () => {
    let { email } = formData;

    let data = { email: email, otp: otp };
    try {
      const result = await axios.post(
        "http://localhost:4000/api/customer/verify",
        data
      );
      localStorage.setItem("_sid", result?.data?.token);
      setsetChangePass(true);
    } catch (error) {
      NotificationManager.error("Otp invalid!", "Input Error");
    }
  };
  const handleSubmitChangePassword = async () => {
    let { password } = formData;

    let data = { password: password };
    try {
      await axios.put("http://localhost:4000/api/customer/editUser", data, {
        headers: {
          Authorization: "Bearer " + localStorage.getItem("_sid"),
        },
      });

      setsetChangePass(true);
      localStorage.removeItem("_sid");
      swal("Notice", "Update password successfully!", "success").then(() => {
        history.push("/");
      });

      // setAuthState({
      //   email: result.data.email,
      //   name: result.data.name,
      //   id: result.data.id,
      //   status: true,
      //   loading: false,
      // });
    } catch (error) {
      NotificationManager.error("Form data invalid!", "Input Error");
    }
  };
  return (
    <div className="card checkout-step-one">
      <div className="card-header" id="headingOne">
        <h5 className="mb-0">
          <button
            className="btn btn-link"
            type="button"
            data-toggle="collapse"
            data-target="#collapseOne"
            aria-expanded="true"
            aria-controls="collapseOne"
          >
            <span className="number">1</span> Login or SignUp
          </button>
        </h5>
      </div>
      <div
        id="collapseOne"
        className="collapse show"
        aria-labelledby="headingOne"
        data-parent="#accordionExample"
      >
        <div
          className="modal-dialog modal-lg modal-dialog-centered"
          role="document"
        >
          <div className="modal-content">
            <div className="modal-body">
              <div className="login-modal login-page-bk">
                <div className="row">
                  <div className="col-lg-6 pad-right-0">
                    <div className="login-modal-left"></div>
                  </div>
                  <div className="col-lg-6 pad-left-0">
                    <div noValidate>
                      <h5 className="heading-design-h5">Forget password!</h5>
                      {!active && (
                        <fieldset className="form-group">
                          <label>Enter Email</label>
                          <input
                            type="text"
                            className="form-control"
                            name="email"
                            value={email || ""}
                            onChange={handleChange}
                          />
                          {formErrors.email.length > 0 && (
                            <span className="errorMessage">
                              {formErrors.email}
                            </span>
                          )}
                        </fieldset>
                      )}
                      {active && (
                        <div
                          style={{ display: "flex", justifyContent: "center" }}
                        >
                          <Box
                            sx={{
                              display: "flex",
                              flexDirection: "column",
                              gap: 2,
                            }}
                          >
                            <OTP
                              separator={<span>-</span>}
                              value={otp}
                              onChange={setOtp}
                              length={4}
                            />
                          </Box>
                        </div>
                      )}
                      {setChangePass && (
                        <fieldset className="form-group">
                          <label>Enter Password</label>
                          <input
                            type="password"
                            className="form-control"
                            name="password"
                            value={password || ""}
                            onChange={handleChange}
                          />
                          {formErrors.password.length > 0 && (
                            <span className="errorMessage">
                              {formErrors.password}
                            </span>
                          )}
                        </fieldset>
                      )}
                      {!setChangePass && (
                        <fieldset className="form-group">
                          <button
                            type="submit"
                            className="btn btn-lg btn-secondary btn-block"
                            onClick={!active ? handleSubmit : handleSubmitOtp}
                            disabled={disable}
                          >
                            {!active ? "Send otp your email!" : "Send otp"}
                          </button>
                        </fieldset>
                      )}
                      {setChangePass && (
                        <fieldset className="form-group">
                          <button
                            type="submit"
                            className="btn btn-lg btn-secondary btn-block"
                            onClick={handleSubmitChangePassword}
                            disabled={disable}
                          >
                            Change password
                          </button>
                        </fieldset>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ForgetPassword;

function OTP({ separator, length, value, onChange }) {
  const inputRefs = React.useRef(new Array(length).fill(null));

  const focusInput = (targetIndex) => {
    const targetInput = inputRefs.current[targetIndex];
    targetInput.focus();
  };

  const selectInput = (targetIndex) => {
    const targetInput = inputRefs.current[targetIndex];
    targetInput.select();
  };

  const handleKeyDown = (event, currentIndex) => {
    switch (event.key) {
      case "ArrowUp":
      case "ArrowDown":
      case " ":
        event.preventDefault();
        break;
      case "ArrowLeft":
        event.preventDefault();
        if (currentIndex > 0) {
          focusInput(currentIndex - 1);
          selectInput(currentIndex - 1);
        }
        break;
      case "ArrowRight":
        event.preventDefault();
        if (currentIndex < length - 1) {
          focusInput(currentIndex + 1);
          selectInput(currentIndex + 1);
        }
        break;
      case "Delete":
        event.preventDefault();
        onChange((prevOtp) => {
          const otp =
            prevOtp.slice(0, currentIndex) + prevOtp.slice(currentIndex + 1);
          return otp;
        });

        break;
      case "Backspace":
        event.preventDefault();
        if (currentIndex > 0) {
          focusInput(currentIndex - 1);
          selectInput(currentIndex - 1);
        }

        onChange((prevOtp) => {
          const otp =
            prevOtp.slice(0, currentIndex) + prevOtp.slice(currentIndex + 1);
          return otp;
        });
        break;

      default:
        break;
    }
  };

  const handleChange = (event, currentIndex) => {
    const currentValue = event.target.value;
    let indexToEnter = 0;

    while (indexToEnter <= currentIndex) {
      if (
        inputRefs.current[indexToEnter].value &&
        indexToEnter < currentIndex
      ) {
        indexToEnter += 1;
      } else {
        break;
      }
    }
    onChange((prev) => {
      const otpArray = prev.split("");
      const lastValue = currentValue[currentValue.length - 1];
      otpArray[indexToEnter] = lastValue;
      return otpArray.join("");
    });
    if (currentValue !== "") {
      if (currentIndex < length - 1) {
        focusInput(currentIndex + 1);
      }
    }
  };

  const handleClick = (event, currentIndex) => {
    selectInput(currentIndex);
  };

  const handlePaste = (event, currentIndex) => {
    event.preventDefault();
    const clipboardData = event.clipboardData;

    // Check if there is text data in the clipboard
    if (clipboardData.types.includes("text/plain")) {
      let pastedText = clipboardData.getData("text/plain");
      pastedText = pastedText.substring(0, length).trim();
      let indexToEnter = 0;

      while (indexToEnter <= currentIndex) {
        if (
          inputRefs.current[indexToEnter].value &&
          indexToEnter < currentIndex
        ) {
          indexToEnter += 1;
        } else {
          break;
        }
      }

      const otpArray = value.split("");

      for (let i = indexToEnter; i < length; i += 1) {
        const lastValue = pastedText[i - indexToEnter] ?? " ";
        otpArray[i] = lastValue;
      }

      onChange(otpArray.join(""));
    }
  };

  return (
    <Box sx={{ display: "flex", gap: 1, alignItems: "center" }}>
      {new Array(length).fill(null).map((_, index) => (
        <React.Fragment key={index}>
          <BaseInput
            slots={{
              input: InputElement,
            }}
            aria-label={`Digit ${index + 1} of OTP`}
            slotProps={{
              input: {
                ref: (ele) => {
                  inputRefs.current[index] = ele;
                },
                onKeyDown: (event) => handleKeyDown(event, index),
                onChange: (event) => handleChange(event, index),
                onClick: (event) => handleClick(event, index),
                onPaste: (event) => handlePaste(event, index),
                value: value[index] ?? "",
              },
            }}
          />
          {index === length - 1 ? null : separator}
        </React.Fragment>
      ))}
    </Box>
  );
}

OTP.propTypes = {
  length: PropTypes.number.isRequired,
  onChange: PropTypes.func.isRequired,
  separator: PropTypes.node,
  value: PropTypes.string.isRequired,
};

const blue = {
  100: "#DAECFF",
  200: "#80BFFF",
  400: "#3399FF",
  500: "#007FFF",
  600: "#0072E5",
  700: "#0059B2",
};

const grey = {
  50: "#F3F6F9",
  100: "#E5EAF2",
  200: "#DAE2ED",
  300: "#C7D0DD",
  400: "#B0B8C4",
  500: "#9DA8B7",
  600: "#6B7A90",
  700: "#434D5B",
  800: "#303740",
  900: "#1C2025",
};

const InputElement = styled("input")(
  ({ theme }) => `
  width: 40px;
  font-family: 'IBM Plex Sans', sans-serif;
  font-size: 0.875rem;
  font-weight: 400;
  line-height: 1.5;
  padding: 8px 0px;
  border-radius: 8px;
  text-align: center;
  color: ${theme.palette.mode === "dark" ? grey[300] : grey[900]};
  background: ${theme.palette.mode === "dark" ? grey[900] : "#fff"};
  border: 1px solid ${theme.palette.mode === "dark" ? grey[700] : grey[200]};
  box-shadow: 0px 2px 4px ${
    theme.palette.mode === "dark" ? "rgba(0,0,0, 0.5)" : "rgba(0,0,0, 0.05)"
  };

  &:hover {
    border-color: ${blue[400]};
  }

  &:focus {
    border-color: ${blue[400]};
    box-shadow: 0 0 0 3px ${
      theme.palette.mode === "dark" ? blue[600] : blue[200]
    };
  }

  // firefox
  &:focus-visible {
    outline: 0;
  }
`
);
