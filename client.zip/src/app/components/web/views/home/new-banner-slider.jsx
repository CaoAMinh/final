import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Navigation, Pagination, Scrollbar, A11y } from "swiper/modules";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import "swiper/css/scrollbar";
const NewBannerSlider = () => {
  const [slidesPerView, setSlidesPerView] = useState(3);

  useEffect(() => {
    function handleResize() {
      if (window.innerWidth < 576) {
        setSlidesPerView(1);
      } else if (window.innerWidth < 768) {
        setSlidesPerView(2);
      } else {
        setSlidesPerView(3);
      }
    }

    handleResize();

    window.addEventListener("resize", handleResize);
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);
  return (
    <Swiper
      className="container"
      modules={[Navigation, Pagination, Scrollbar, A11y]}
      spaceBetween={50}
      slidesPerView={slidesPerView}
      navigation
      pagination={{ clickable: true }}
      scrollbar={{ draggable: true }}
    >
      <SwiperSlide className="containers">
        <Link to="#">
          <img
            src="https://routine.vn/pub/media/wysiwyg/ECOM_600x950_2.jpg"
            alt="Giảm 50% cho sản phẩm thứ 2"
          />
        </Link>
        <Link className="btn" style={{ textTransform: "uppercase" }} to="#">
          Xem ngay
        </Link>
      </SwiperSlide>
      <SwiperSlide className="containers">
        <Link to="#">
          <img
            src="https://routine.vn/pub/media/wysiwyg/Untitled-2-01.jpg"
            alt="Áo khoác giá tốt 399k/áo khi mua từ 2 áo"
          />
        </Link>
        <Link
          className="btn"
          style={{ textTransform: "uppercase" }}
          to="/promotion/ao-khoac-399k"
        >
          Xem ngay
        </Link>
      </SwiperSlide>{" "}
      <SwiperSlide className="containers">
        <Link to="#">
          <img
            src="https://routine.vn/pub/media/wysiwyg/ECOM_600x950_copy_2.jpg"
            alt="Mua 1 tặng 1"
          />
        </Link>
        <Link className="btn" style={{ textTransform: "uppercase" }} to="#">
          Xem ngay
        </Link>
      </SwiperSlide>
    </Swiper>
  );
};

export default NewBannerSlider;
