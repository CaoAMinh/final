import axios from "axios";
import { API_URL } from "../../../../config1";

const emptyCart = async () => {};

export default emptyCart;
