import api from "../../../../app/ApiConfig";
import { Apis } from "../../../../config";
import { NotificationManager } from "react-notifications";
import Cookies from "js-cookie";
const getUserLogin = async (data) => {
  try {
    let result = await api.post(Apis.GetUserLogin, data, {
      withCredentials: true,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json",
      },
    });
    if (result.data.error) {
      NotificationManager.error(result.data.error);
      return null;
    }
    Cookies.set("udata", result?.data);
    localStorage.setItem("_sid", result?.data?.token);
    return result.data;
  } catch (error) {
    console.log(error);
    return null;
  }
};

const getUserRegister = async (data) => {
  let result = await api.post(Apis.GetUserRegsiter, data);
  return result;
};

const authenticate = async (data, email) => {
  if (typeof window !== "undefined") {
    localStorage.setItem("_sid", data);
    localStorage.setItem("email", email);
    setTimeout(function () {
      window.location.reload();
    }, 1000);
  }
};

const getCustomerDetail = async (email) => {
  try {
    let result = await api.get(Apis.GetCustomerDetails + email);
    if (result.data.error) {
      NotificationManager.error(result.data.error);
      return null;
    }
    return result.data;
  } catch (error) {
    console.log(error);
    return null;
  }
};

const getCustomerUpdate = async (data) => {
  try {
    let result = await api.post(Apis.GetCustomerUpdateDetails, { data });
    if (result.data.error) {
      NotificationManager.error(result.data.error);
      return null;
    }
    return result.data;
  } catch (error) {
    console.log(error);
    return null;
  }
};

const authenticateByCart = async (token, email) => {
  if (typeof window !== "undefined") {
    localStorage.setItem("_sid", token);
    localStorage.setItem("email", email);
  } else {
    NotificationManager.error("Please check your login", "Input Error");
  }
};

const logout = (next) => {
  if (typeof window !== "undefined") {
    localStorage.removeItem("_sid");
    localStorage.removeItem("email");

    window.location.href = "/";
    next();
  }
};

const isAuthenticate = () => {
  if (typeof window === "undefined") {
    return false;
  }
  return localStorage.getItem("_sid");
};
const exports = {
  getUserLogin,
  authenticate,
  isAuthenticate,
  authenticateByCart,
  getUserRegister,
  getCustomerDetail,
  getCustomerUpdate,
  logout,
};
export default exports;
