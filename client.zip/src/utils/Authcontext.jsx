import axios from "axios";
import { createContext, useEffect, useState } from "react";

export const AuthContext = createContext("");

function ProviderAuth({ children }) {
  const [loading, setLoading] = useState(false);
  const [authState, setAuthState] = useState({
    username: "",
    id: 0,
    status: false,
    loading: false,
  });
  useEffect(() => {
    axios
      .get("http://localhost:4000/api/customer/auth", {
        headers: {
          Authorization: "Bearer " + localStorage.getItem("_sid"),
        },
      })
      .then((response) => {
        console.log(response.data);
        if (response.data.error) {
          setAuthState({
            ...authState,

            status: false,
          });
        } else {
          setAuthState({
            email: response.data.email,
            name: response.data.name,
            id: response.data.id,
            status: true,
            loading: false,
          });
        }
        setLoading(true);
      })
      .catch(() => {
        setAuthState({ ...authState, status: false, loading: false });
        setLoading(true);
        localStorage.removeItem("_sid");
      });
  }, []);
  return (
    <AuthContext.Provider value={{ authState, setAuthState }}>
      {loading && children}
    </AuthContext.Provider>
  );
}

export default ProviderAuth;

//  useEffect(() => {
//    const fetchData = async () => {
//      try {
//        dispatch({ type: "FETCH_START" });
//        const response = await axios.get(
//          "https://jsonplaceholder.typicode.com/comments"
//        );
//        dispatch({ type: "FETCH_SUCCESS", payload: response.data });
//      } catch (error) {
//        dispatch({ type: "FETCH_ERROR" });
//      }
//    };
//    fetchData();
//  }, []);
// const [state, dispatch] = useReducer(loginReducer, INITIAL_STATE);
