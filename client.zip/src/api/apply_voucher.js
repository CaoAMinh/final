import axios from "axios";
import { API_URL } from "../config1";
import swal from "sweetalert";

const apply_voucher = async (data) => {
  const res = await axios({
    url: API_URL + "/api/voucher/apply",
    method: "post",
    data: {
      ...data,
    },
    headers: {
      Authorization: "Bearer " + localStorage.getItem("_sid"),
    },
  });
  try {
    const result = await res.data;
    return result;
  } catch (error) {
    swal("Notice", "Voucher không hợp lệ hoặc đã hết hạn", "error");
  }
};

export default apply_voucher;
